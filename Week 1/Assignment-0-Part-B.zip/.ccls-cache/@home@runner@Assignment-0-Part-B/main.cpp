// Nathalie Himaya
// CIS-17C
// Assignment #0, Part B

#include <iostream>
#include <fstream>
using namespace std;

const int SIZE = 15;
// Function Prototypes
void readPrices(ifstream& myfile,int arr[]);
void displayPrices(int arr[], int SIZE);

// Main Funtion
int main() {
  int arr[SIZE];
  ifstream myfile;
  myfile.open("prices.txt"); //Opens the file

  readPrices(myfile, arr); //Call Read Prices
  displayPrices(arr, SIZE); //Display Prices
}

//Function Definitions
void readPrices(ifstream& myfile,int arr[]){ // Reads the Prices of the file
  for(int i = 0; i < SIZE; i++){
     myfile >> arr[i];
   }
}

void displayPrices(int arr[], int SIZE){ // Prints the numbers of the txt
   for(int i = 0; i < SIZE; i++){
     cout << "$" << arr[i] << endl;
   }
}
